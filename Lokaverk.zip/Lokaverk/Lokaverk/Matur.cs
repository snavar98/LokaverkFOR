﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lokaverk
{
    public partial class Matur : Form
    {
        Gagnagrunnur gagnagrunnur = new Gagnagrunnur();

        private string matvaran;
        private string verdid;
        public Matur(string matur = null, string verd = null)
        {
            InitializeComponent();

            matvaran = matur;
            verdid = verd;

            txtMatvara.Text = matvaran;
            txtNyttVerd.Text = verdid;

            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnStadfesta_Click(object sender, EventArgs e)
        {
            matvaran = txtMatvara.Text;
            verdid = txtNyttVerd.Text;

            string[] gognFraSQL = new string[3];
            string maturFraGrunni = null;
            string verdFraGrunni = null;


            try
            {
                gognFraSQL = gagnagrunnur.Finna(matvaran);
                maturFraGrunni = gognFraSQL[0];
                verdFraGrunni = gognFraSQL[1];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            if (verdFraGrunni == verdid)
            {
                MessageBox.Show("Afhverju ættiru að breyta verðinu úr " + verdid + " í " + verdFraGrunni + "? \n Það meikar engan sens.");
            }

            else if (verdid == "0")
            {
                MessageBox.Show("Þetta er nú ekki ókeypis.");
            }

            else
            {
                MessageBox.Show("Verðinu hefur verið breytt úr " + verdFraGrunni + " í " + verdid + ".");
                gagnagrunnur.Uppfaera(verdid, verdFraGrunni, maturFraGrunni);
                this.Close();
            }
        }

        private void Uppfaera(string verd, string verdgrunni, string matur)
        {
            try
            {
                gagnagrunnur.Uppfaera(verd, verdgrunni, matur);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
