﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lokaverk
{
    public partial class Form1 : Form
    {
        Gagnagrunnur gagnagrunnur = new Gagnagrunnur();
        List<string> listi = new List<string>();
        bool gamli = false;
        int summa = 0;
        int numer = 1;
        public Form1()
        {
            InitializeComponent();
            gagnagrunnur.TengingVidGagnagrunn();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
        }

        private void btnBorga_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            if (summa == 0)
            {
                MessageBox.Show("Verður að stimpla einhvað inn til að versla");
            }
            else
            {
                MessageBox.Show("-----Kvittun og númer------\n \n \n \n Verð Samtals = " + summa + "kr. \n \n \n \n Númerið þitt er: " + numer);
                MessageBox.Show("Takk fyrir að versla hjá Söluskála Sigfúsar");
            }
            numer++;
            summa = summa - summa;
        }

        private void btnHamborgari_Click(object sender, EventArgs e)
        {
            summa = summa + 875;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Hamborgari();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnOstborgari_Click(object sender, EventArgs e)
        {
            summa = summa + 925;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Ostborgari();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnBeikonborgari_Click(object sender, EventArgs e)
        {
            summa = summa + 1005;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Beikonborgari();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnKjuklingaborgari_Click(object sender, EventArgs e)
        {
            summa = summa + 1105;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Kjuklingaborgari();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnFiskur_Click(object sender, EventArgs e)
        {
            summa = summa + 850;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Fiskur();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnKjukT_Click(object sender, EventArgs e)
        {
            summa = summa + 1250;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Kjuklingatortilla();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnGraenT_Click(object sender, EventArgs e)
        {
            summa = summa + 1150;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Graenmetistortilla();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnGraenPita_Click(object sender, EventArgs e)
        {
            summa = summa + 900;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Graenmetispita();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnSamloka_Click(object sender, EventArgs e)
        {
            summa = summa + 520;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Samloka();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnOstastangir_Click(object sender, EventArgs e)
        {
            summa = summa + 460;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Ostastangir();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnFranskar_Click(object sender, EventArgs e)
        {
            summa = summa + 320;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Franskar();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnGos_Click(object sender, EventArgs e)
        {
            summa = summa + 250;
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("Matur", 250);
            listView1.Columns.Add("Verð", 89);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Gos();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }
    }
}
