﻿namespace Lokaverk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnBorga = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnHamborgari = new System.Windows.Forms.Button();
            this.btnOstborgari = new System.Windows.Forms.Button();
            this.btnBeikonborgari = new System.Windows.Forms.Button();
            this.btnOstastangir = new System.Windows.Forms.Button();
            this.btnKjukT = new System.Windows.Forms.Button();
            this.btnSamloka = new System.Windows.Forms.Button();
            this.btnFiskur = new System.Windows.Forms.Button();
            this.btnGos = new System.Windows.Forms.Button();
            this.btnGraenPita = new System.Windows.Forms.Button();
            this.btnFranskar = new System.Windows.Forms.Button();
            this.btnGraenT = new System.Windows.Forms.Button();
            this.btnKjuklingaborgari = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Kjötréttir = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBorga
            // 
            this.btnBorga.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorga.Image = ((System.Drawing.Image)(resources.GetObject("btnBorga.Image")));
            this.btnBorga.Location = new System.Drawing.Point(361, 25);
            this.btnBorga.Name = "btnBorga";
            this.btnBorga.Size = new System.Drawing.Size(343, 285);
            this.btnBorga.TabIndex = 0;
            this.btnBorga.Text = "BORGA";
            this.btnBorga.UseVisualStyleBackColor = true;
            this.btnBorga.Click += new System.EventHandler(this.btnBorga_Click);
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(12, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(343, 284);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // btnHamborgari
            // 
            this.btnHamborgari.BackColor = System.Drawing.Color.Red;
            this.btnHamborgari.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHamborgari.Location = new System.Drawing.Point(12, 333);
            this.btnHamborgari.Name = "btnHamborgari";
            this.btnHamborgari.Size = new System.Drawing.Size(166, 71);
            this.btnHamborgari.TabIndex = 2;
            this.btnHamborgari.Text = "Hamborgari";
            this.btnHamborgari.UseVisualStyleBackColor = false;
            this.btnHamborgari.Click += new System.EventHandler(this.btnHamborgari_Click);
            // 
            // btnOstborgari
            // 
            this.btnOstborgari.BackColor = System.Drawing.Color.Red;
            this.btnOstborgari.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOstborgari.Location = new System.Drawing.Point(189, 333);
            this.btnOstborgari.Name = "btnOstborgari";
            this.btnOstborgari.Size = new System.Drawing.Size(166, 71);
            this.btnOstborgari.TabIndex = 3;
            this.btnOstborgari.Text = "Ostborgari";
            this.btnOstborgari.UseVisualStyleBackColor = false;
            this.btnOstborgari.Click += new System.EventHandler(this.btnOstborgari_Click);
            // 
            // btnBeikonborgari
            // 
            this.btnBeikonborgari.BackColor = System.Drawing.Color.Red;
            this.btnBeikonborgari.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBeikonborgari.Location = new System.Drawing.Point(361, 333);
            this.btnBeikonborgari.Name = "btnBeikonborgari";
            this.btnBeikonborgari.Size = new System.Drawing.Size(166, 71);
            this.btnBeikonborgari.TabIndex = 4;
            this.btnBeikonborgari.Text = "Beikonborgari";
            this.btnBeikonborgari.UseVisualStyleBackColor = false;
            this.btnBeikonborgari.Click += new System.EventHandler(this.btnBeikonborgari_Click);
            // 
            // btnOstastangir
            // 
            this.btnOstastangir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnOstastangir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOstastangir.Location = new System.Drawing.Point(189, 509);
            this.btnOstastangir.Name = "btnOstastangir";
            this.btnOstastangir.Size = new System.Drawing.Size(166, 71);
            this.btnOstastangir.TabIndex = 5;
            this.btnOstastangir.Text = "Ostastangir";
            this.btnOstastangir.UseVisualStyleBackColor = false;
            this.btnOstastangir.Click += new System.EventHandler(this.btnOstastangir_Click);
            // 
            // btnKjukT
            // 
            this.btnKjukT.BackColor = System.Drawing.Color.Red;
            this.btnKjukT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKjukT.Location = new System.Drawing.Point(189, 421);
            this.btnKjukT.Name = "btnKjukT";
            this.btnKjukT.Size = new System.Drawing.Size(166, 71);
            this.btnKjukT.TabIndex = 6;
            this.btnKjukT.Text = "Kjúklingatortilla";
            this.btnKjukT.UseVisualStyleBackColor = false;
            this.btnKjukT.Click += new System.EventHandler(this.btnKjukT_Click);
            // 
            // btnSamloka
            // 
            this.btnSamloka.BackColor = System.Drawing.Color.Red;
            this.btnSamloka.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSamloka.Location = new System.Drawing.Point(12, 509);
            this.btnSamloka.Name = "btnSamloka";
            this.btnSamloka.Size = new System.Drawing.Size(166, 71);
            this.btnSamloka.TabIndex = 7;
            this.btnSamloka.Text = "Samloka m/ skinku og osti";
            this.btnSamloka.UseVisualStyleBackColor = false;
            this.btnSamloka.Click += new System.EventHandler(this.btnSamloka_Click);
            // 
            // btnFiskur
            // 
            this.btnFiskur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnFiskur.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFiskur.Location = new System.Drawing.Point(12, 421);
            this.btnFiskur.Name = "btnFiskur";
            this.btnFiskur.Size = new System.Drawing.Size(166, 71);
            this.btnFiskur.TabIndex = 8;
            this.btnFiskur.Text = "Fiskur";
            this.btnFiskur.UseVisualStyleBackColor = false;
            this.btnFiskur.Click += new System.EventHandler(this.btnFiskur_Click);
            // 
            // btnGos
            // 
            this.btnGos.BackColor = System.Drawing.Color.Blue;
            this.btnGos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGos.Location = new System.Drawing.Point(538, 509);
            this.btnGos.Name = "btnGos";
            this.btnGos.Size = new System.Drawing.Size(166, 71);
            this.btnGos.TabIndex = 9;
            this.btnGos.Text = "Gos";
            this.btnGos.UseVisualStyleBackColor = false;
            this.btnGos.Click += new System.EventHandler(this.btnGos_Click);
            // 
            // btnGraenPita
            // 
            this.btnGraenPita.BackColor = System.Drawing.Color.Lime;
            this.btnGraenPita.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGraenPita.Location = new System.Drawing.Point(538, 421);
            this.btnGraenPita.Name = "btnGraenPita";
            this.btnGraenPita.Size = new System.Drawing.Size(166, 71);
            this.btnGraenPita.TabIndex = 10;
            this.btnGraenPita.Text = "Grænmetispíta";
            this.btnGraenPita.UseVisualStyleBackColor = false;
            this.btnGraenPita.Click += new System.EventHandler(this.btnGraenPita_Click);
            // 
            // btnFranskar
            // 
            this.btnFranskar.BackColor = System.Drawing.Color.Lime;
            this.btnFranskar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFranskar.Location = new System.Drawing.Point(361, 509);
            this.btnFranskar.Name = "btnFranskar";
            this.btnFranskar.Size = new System.Drawing.Size(166, 71);
            this.btnFranskar.TabIndex = 11;
            this.btnFranskar.Text = "Franskar";
            this.btnFranskar.UseVisualStyleBackColor = false;
            this.btnFranskar.Click += new System.EventHandler(this.btnFranskar_Click);
            // 
            // btnGraenT
            // 
            this.btnGraenT.BackColor = System.Drawing.Color.Lime;
            this.btnGraenT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGraenT.Location = new System.Drawing.Point(361, 421);
            this.btnGraenT.Name = "btnGraenT";
            this.btnGraenT.Size = new System.Drawing.Size(166, 71);
            this.btnGraenT.TabIndex = 12;
            this.btnGraenT.Text = "Grænmetistortilla";
            this.btnGraenT.UseVisualStyleBackColor = false;
            this.btnGraenT.Click += new System.EventHandler(this.btnGraenT_Click);
            // 
            // btnKjuklingaborgari
            // 
            this.btnKjuklingaborgari.BackColor = System.Drawing.Color.Red;
            this.btnKjuklingaborgari.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKjuklingaborgari.Location = new System.Drawing.Point(538, 333);
            this.btnKjuklingaborgari.Name = "btnKjuklingaborgari";
            this.btnKjuklingaborgari.Size = new System.Drawing.Size(166, 71);
            this.btnKjuklingaborgari.TabIndex = 13;
            this.btnKjuklingaborgari.Text = "Kjúklingaborgari";
            this.btnKjuklingaborgari.UseVisualStyleBackColor = false;
            this.btnKjuklingaborgari.Click += new System.EventHandler(this.btnKjuklingaborgari_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Location = new System.Drawing.Point(12, 586);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 23);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox2.Location = new System.Drawing.Point(189, 586);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 23);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Lime;
            this.pictureBox3.Location = new System.Drawing.Point(361, 586);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 23);
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pictureBox4.Location = new System.Drawing.Point(538, 586);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(22, 23);
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // Kjötréttir
            // 
            this.Kjötréttir.AutoSize = true;
            this.Kjötréttir.Location = new System.Drawing.Point(40, 592);
            this.Kjötréttir.Name = "Kjötréttir";
            this.Kjötréttir.Size = new System.Drawing.Size(51, 13);
            this.Kjötréttir.TabIndex = 18;
            this.Kjötréttir.Text = "- Kjötréttir";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(217, 592);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "- Vegetarian";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(389, 592);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "- Vegan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(566, 592);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "- Drykkir";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(267, 626);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 71);
            this.button1.TabIndex = 22;
            this.button1.Text = "Breyta verði á matvöru";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 699);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Kjötréttir);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnKjuklingaborgari);
            this.Controls.Add(this.btnGraenT);
            this.Controls.Add(this.btnFranskar);
            this.Controls.Add(this.btnGraenPita);
            this.Controls.Add(this.btnGos);
            this.Controls.Add(this.btnFiskur);
            this.Controls.Add(this.btnSamloka);
            this.Controls.Add(this.btnKjukT);
            this.Controls.Add(this.btnOstastangir);
            this.Controls.Add(this.btnBeikonborgari);
            this.Controls.Add(this.btnOstborgari);
            this.Controls.Add(this.btnHamborgari);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btnBorga);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBorga;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnHamborgari;
        private System.Windows.Forms.Button btnOstborgari;
        private System.Windows.Forms.Button btnBeikonborgari;
        private System.Windows.Forms.Button btnOstastangir;
        private System.Windows.Forms.Button btnKjukT;
        private System.Windows.Forms.Button btnSamloka;
        private System.Windows.Forms.Button btnFiskur;
        private System.Windows.Forms.Button btnGos;
        private System.Windows.Forms.Button btnGraenPita;
        private System.Windows.Forms.Button btnFranskar;
        private System.Windows.Forms.Button btnGraenT;
        private System.Windows.Forms.Button btnKjuklingaborgari;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label Kjötréttir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
    }
}

