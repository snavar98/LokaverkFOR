﻿namespace Lokaverk
{
    partial class Matur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnStadfesta = new System.Windows.Forms.Button();
            this.txtMatvara = new System.Windows.Forms.TextBox();
            this.txtNyttVerd = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtNyttVerd);
            this.groupBox1.Controls.Add(this.txtMatvara);
            this.groupBox1.Controls.Add(this.btnStadfesta);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(5, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(449, 165);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Veldu nýtt verð á matvöru";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matvara";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nýtt verð";
            // 
            // btnStadfesta
            // 
            this.btnStadfesta.Location = new System.Drawing.Point(64, 125);
            this.btnStadfesta.Name = "btnStadfesta";
            this.btnStadfesta.Size = new System.Drawing.Size(334, 30);
            this.btnStadfesta.TabIndex = 2;
            this.btnStadfesta.Text = "Staðfesta nýtt verð";
            this.btnStadfesta.UseVisualStyleBackColor = true;
            this.btnStadfesta.Click += new System.EventHandler(this.btnStadfesta_Click);
            // 
            // txtMatvara
            // 
            this.txtMatvara.Location = new System.Drawing.Point(156, 45);
            this.txtMatvara.Name = "txtMatvara";
            this.txtMatvara.Size = new System.Drawing.Size(242, 20);
            this.txtMatvara.TabIndex = 3;
            // 
            // txtNyttVerd
            // 
            this.txtNyttVerd.Location = new System.Drawing.Point(156, 76);
            this.txtNyttVerd.Name = "txtNyttVerd";
            this.txtNyttVerd.Size = new System.Drawing.Size(242, 20);
            this.txtNyttVerd.TabIndex = 4;
            // 
            // Matur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 173);
            this.Controls.Add(this.groupBox1);
            this.Name = "Matur";
            this.Text = "Matur";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNyttVerd;
        private System.Windows.Forms.TextBox txtMatvara;
        private System.Windows.Forms.Button btnStadfesta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}