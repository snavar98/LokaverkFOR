﻿namespace hlutaprof3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnTolur = new System.Windows.Forms.Button();
            this.btnMedal = new System.Windows.Forms.Button();
            this.btnSex = new System.Windows.Forms.Button();
            this.rtxtRandom = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNafn = new System.Windows.Forms.TextBox();
            this.txtLengd = new System.Windows.Forms.TextBox();
            this.btnEyda = new System.Windows.Forms.Button();
            this.btnBaeta = new System.Windows.Forms.Button();
            this.btnAllir = new System.Windows.Forms.Button();
            this.btnuppfaera = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(560, 454);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnTolur);
            this.tabPage1.Controls.Add(this.btnMedal);
            this.tabPage1.Controls.Add(this.btnSex);
            this.tabPage1.Controls.Add(this.rtxtRandom);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(552, 428);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Klassar";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnTolur
            // 
            this.btnTolur.Location = new System.Drawing.Point(394, 161);
            this.btnTolur.Name = "btnTolur";
            this.btnTolur.Size = new System.Drawing.Size(114, 55);
            this.btnTolur.TabIndex = 9;
            this.btnTolur.Text = "Tölur milli 1150 - 1170";
            this.btnTolur.UseVisualStyleBackColor = true;
            this.btnTolur.Click += new System.EventHandler(this.btnTolur_Click);
            // 
            // btnMedal
            // 
            this.btnMedal.Location = new System.Drawing.Point(394, 16);
            this.btnMedal.Name = "btnMedal";
            this.btnMedal.Size = new System.Drawing.Size(114, 55);
            this.btnMedal.TabIndex = 8;
            this.btnMedal.Text = "Meðaltal";
            this.btnMedal.UseVisualStyleBackColor = true;
            // 
            // btnSex
            // 
            this.btnSex.Location = new System.Drawing.Point(394, 331);
            this.btnSex.Name = "btnSex";
            this.btnSex.Size = new System.Drawing.Size(114, 52);
            this.btnSex.TabIndex = 7;
            this.btnSex.Text = "Tölur sem 6 gengur uppí og meðaltal þeirra";
            this.btnSex.UseVisualStyleBackColor = true;
            // 
            // rtxtRandom
            // 
            this.rtxtRandom.Location = new System.Drawing.Point(7, 16);
            this.rtxtRandom.Name = "rtxtRandom";
            this.rtxtRandom.Size = new System.Drawing.Size(370, 367);
            this.rtxtRandom.TabIndex = 6;
            this.rtxtRandom.Text = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnuppfaera);
            this.tabPage2.Controls.Add(this.btnAllir);
            this.tabPage2.Controls.Add(this.btnBaeta);
            this.tabPage2.Controls.Add(this.btnEyda);
            this.tabPage2.Controls.Add(this.txtLengd);
            this.tabPage2.Controls.Add(this.txtNafn);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.listView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(552, 428);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SQL";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(8, 7);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(299, 273);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nafn stökkvara:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Lengd stökks:";
            // 
            // txtNafn
            // 
            this.txtNafn.Location = new System.Drawing.Point(118, 300);
            this.txtNafn.Name = "txtNafn";
            this.txtNafn.Size = new System.Drawing.Size(100, 20);
            this.txtNafn.TabIndex = 3;
            // 
            // txtLengd
            // 
            this.txtLengd.Location = new System.Drawing.Point(118, 325);
            this.txtLengd.Name = "txtLengd";
            this.txtLengd.Size = new System.Drawing.Size(100, 20);
            this.txtLengd.TabIndex = 4;
            // 
            // btnEyda
            // 
            this.btnEyda.Location = new System.Drawing.Point(32, 366);
            this.btnEyda.Name = "btnEyda";
            this.btnEyda.Size = new System.Drawing.Size(90, 23);
            this.btnEyda.TabIndex = 5;
            this.btnEyda.Text = "Eyða úr töflu";
            this.btnEyda.UseVisualStyleBackColor = true;
            this.btnEyda.Click += new System.EventHandler(this.btnEyda_Click);
            // 
            // btnBaeta
            // 
            this.btnBaeta.Location = new System.Drawing.Point(128, 366);
            this.btnBaeta.Name = "btnBaeta";
            this.btnBaeta.Size = new System.Drawing.Size(90, 23);
            this.btnBaeta.TabIndex = 6;
            this.btnBaeta.Text = "Bæta í töflu";
            this.btnBaeta.UseVisualStyleBackColor = true;
            this.btnBaeta.Click += new System.EventHandler(this.btnBaeta_Click);
            // 
            // btnAllir
            // 
            this.btnAllir.Location = new System.Drawing.Point(328, 17);
            this.btnAllir.Name = "btnAllir";
            this.btnAllir.Size = new System.Drawing.Size(154, 45);
            this.btnAllir.TabIndex = 7;
            this.btnAllir.Text = "Sýna alla sem stukku yfir 150";
            this.btnAllir.UseVisualStyleBackColor = true;
            this.btnAllir.Click += new System.EventHandler(this.btnAllir_Click);
            // 
            // btnuppfaera
            // 
            this.btnuppfaera.Location = new System.Drawing.Point(328, 81);
            this.btnuppfaera.Name = "btnuppfaera";
            this.btnuppfaera.Size = new System.Drawing.Size(154, 45);
            this.btnuppfaera.TabIndex = 8;
            this.btnuppfaera.Text = "Sýna alla í SQL töflu";
            this.btnuppfaera.UseVisualStyleBackColor = true;
            this.btnuppfaera.Click += new System.EventHandler(this.btnuppfaera_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 453);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnTolur;
        private System.Windows.Forms.Button btnMedal;
        private System.Windows.Forms.Button btnSex;
        private System.Windows.Forms.RichTextBox rtxtRandom;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnuppfaera;
        private System.Windows.Forms.Button btnAllir;
        private System.Windows.Forms.Button btnBaeta;
        private System.Windows.Forms.Button btnEyda;
        private System.Windows.Forms.TextBox txtLengd;
        private System.Windows.Forms.TextBox txtNafn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
    }
}

