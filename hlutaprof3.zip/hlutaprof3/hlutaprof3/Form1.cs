﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hlutaprof3
{
    public partial class Form1 : Form
    {
        Klassar klassar = new Klassar();
        Gagnagrunnur gagnagrunnur = new Gagnagrunnur();
        List<string> listi = new List<string>();
        Random rand = new Random();
        List<int> tolur = new List<int>();
        List<int> milli = new List<int>();
        bool gamli = false;
        int summa = 0;
        public Form1()
        {
            InitializeComponent();
            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            } 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("nafn", 200);
            listView1.Columns.Add("Lengd", 150);
            int tala = 0;
            for (int i = 0; i < 100; i++)
            {
                tala = rand.Next(1100, 1200);
                if (tala < 1149)
                {
                    if (tala > 1171)
                    {
                        milli.Add(tala);
                    }
                }
                tolur.Add(tala);
                rtxtRandom.Text += tala + " ";
                
            }

        }

        private void btnBaeta_Click(object sender, EventArgs e)
        {
            string nafn = txtNafn.Text;
            string lengd = txtLengd.Text;

            try
            {
                gagnagrunnur.SettInn(nafn, lengd);
                MessageBox.Show(nafn + ", lengdin á stökkinu þínu hefur verið bætt við");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            txtLengd.Clear();
            txtNafn.Clear();
        }

        private void btnEyda_Click(object sender, EventArgs e)
        {
            string nafn = txtNafn.Text;
            string lengd = txtLengd.Text;

            try
            {
                gagnagrunnur.EyttUr(nafn, lengd);
                MessageBox.Show(nafn + ", Þér hefur verið eytt úr grunninum");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            txtLengd.Clear();
            txtNafn.Clear();
        }

        private void btnuppfaera_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("nafn", 200);
            listView1.Columns.Add("Lengd", 95);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.LesaUrSQLToflu();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnAllir_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            foreach (var item in listView1.Columns)
            {
                listView1.Columns.RemoveAt(0);
            }
            listView1.Columns.Add("nafn", 200);
            listView1.Columns.Add("Lengd", 95);
            ListViewItem itm;
            gamli = true;
            try
            {
                listi = gagnagrunnur.Yfir150();
                string[] fusi;
                foreach (var stuff in listi)
                {
                    fusi = stuff.Split(':');
                    itm = new ListViewItem(fusi);
                    listView1.Items.Add(itm);
                    //summa += Convert.ToInt32(fusi[0]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Villa: " + ex);
            }
        }

        private void btnTolur_Click(object sender, EventArgs e)
        {
           rtxtRandom.Text = Convert.ToString(milli);

        }

    }
}
